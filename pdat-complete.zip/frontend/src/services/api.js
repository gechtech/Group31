const API_BASE = process.env.REACT_APP_API_BASE || 'http://localhost:5000';

export async function checkUrl(url){
  const res = await fetch(API_BASE + '/check-url', {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({url})
  });
  return res.json();
}

export async function checkEmail(email){
  const res = await fetch(API_BASE + '/check-email', {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({email})
  });
  return res.json();
}

export async function uploadFile(file){
  const fd = new FormData(); fd.append('file', file);
  const res = await fetch(API_BASE + '/upload-file', { method: 'POST', body: fd });
  return res.json();
}
