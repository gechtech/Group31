import React from 'react';
import PDATFrontendSidebar from './PDAT_Frontend_Sidebar';

function App(){
  return <PDATFrontendSidebar />;
}

export default App;
