import React, { useState, useRef } from 'react';
const API_BASE = process.env.REACT_APP_API_BASE || 'http://localhost:5000';

const ATTACK_TYPES = [
  { id: 'phishing', label: 'Phishing (Email)' },
  { id: 'malicious-url', label: 'Malicious URL' },
  { id: 'baiting', label: 'Baiting (File)' },
  { id: 'pretexting', label: 'Pretexting' },
  { id: 'tailgating', label: 'Tailgating' },
  { id: 'quid-pro-quo', label: 'Quid pro quo' },
];

const styles = {
  layout: { display: 'flex', minHeight: '100vh', fontFamily: 'Arial, sans-serif' },
  sidebar: { width: 260, background: '#ffffff', borderRight: '1px solid #e5e7eb', padding: 16 },
  main: { flex: 1, padding: 24, background: '#f7fafc' },
  button: { padding: '8px 12px', borderRadius: 6, border: '1px solid #d1d5db', background: '#f3f4f6' },
  primary: { background: '#2563eb', color: 'white', padding: '8px 12px', border: 'none', borderRadius: 6 }
};

export default function PDATFrontendSidebar(){
  const [selected, setSelected] = useState(ATTACK_TYPES[0].id);
  const [urlInput, setUrlInput] = useState('');
  const [emailInput, setEmailInput] = useState('');
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);
  const fileRef = useRef(null);

  function selectType(id){ setSelected(id); setResult(null); }

  async function callApi(path, options){
    setLoading(true); setResult(null);
    try{
      const res = await fetch(API_BASE + path, options);
      const json = await res.json();
      setResult(json);
      setHistory(h => [{ when: new Date().toISOString(), type: selected, data: json }, ...h]);
    }catch(err){
      setResult({ error: 'Request failed', details: String(err) });
    }finally{ setLoading(false); }
  }

  async function handleCheckUrl(e){
    e && e.preventDefault();
    if(!urlInput) return setResult({ error: 'Please enter a URL' });
    await callApi('/check-url', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: urlInput })
    });
  }

  async function handleCheckEmail(e){
    e && e.preventDefault();
    if(!emailInput) return setResult({ error: 'Please paste email content' });
    await callApi('/check-email', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: emailInput })
    });
  }

  async function handleUploadFile(e){
    e && e.preventDefault();
    if(!file) return setResult({ error: 'Please attach a file' });
    const fd = new FormData();
    fd.append('file', file);
    await callApi('/upload-file', { method: 'POST', body: fd });
  }

  function onDrop(ev){ ev.preventDefault(); const f = ev.dataTransfer.files?.[0]; if(f) setFile(f); }
  function onDragOver(ev){ ev.preventDefault(); }

  function prettyJSON(obj){ try{ return JSON.stringify(obj, null, 2); }catch{ return String(obj); } }

  return (
    <div style={styles.layout}>
      <aside style={styles.sidebar}>
        <h2 style={{fontSize:18, fontWeight:700}}>PDAT — Scanner</h2>
        <p style={{color:'#6b7280'}}>Choose an attack type</p>
        <nav style={{marginTop:12}}>
          {ATTACK_TYPES.map(t => (
            <div key={t.id} style={{marginBottom:8}}>
              <button onClick={() => selectType(t.id)} style={{...styles.button, width:'100%', display:'flex', justifyContent:'space-between', background: selected===t.id ? '#eef2ff' : styles.button.background}}>
                <span>{t.label}</span>
                {selected===t.id && <span style={{fontSize:12, color:'#2563eb'}}>selected</span>}
              </button>
            </div>
          ))}
        </nav>
        <div style={{marginTop:20, fontSize:12, color:'#6b7280'}}>
          <div>Quick actions</div>
          <div style={{marginTop:8}}>
            <button onClick={() => { setUrlInput(''); setEmailInput(''); setFile(null); setResult(null); }} style={{...styles.button, marginRight:8}}>Clear</button>
            <button onClick={() => { navigator.clipboard?.writeText(window.location.href); }} style={styles.button}>Copy link</button>
          </div>
        </div>
      </aside>

      <main style={styles.main}>
        <div style={{maxWidth:900, margin:'0 auto'}}>
          <h1 style={{fontSize:22, fontWeight:700, marginBottom:12}}>{ATTACK_TYPES.find(a => a.id===selected).label}</h1>
          <div style={{background:'white', borderRadius:8, padding:16, boxShadow:'0 1px 3px rgba(0,0,0,0.06)'}}>
            {(selected==='malicious-url' || selected==='phishing') && (
              <section style={{marginBottom:16}}>
                <h3 style={{fontWeight:600}}>Check a URL</h3>
                <form onSubmit={handleCheckUrl} style={{marginTop:8, display:'flex', gap:8}}>
                  <input value={urlInput} onChange={e=>setUrlInput(e.target.value)} placeholder="https://example.com/login" style={{flex:1,padding:8,borderRadius:6,border:'1px solid #e5e7eb'}} />
                  <button style={styles.primary} disabled={loading}>Scan</button>
                </form>
              </section>
            )}

            {selected==='phishing' && (
              <section style={{marginBottom:16}}>
                <h3 style={{fontWeight:600}}>Analyze email content</h3>
                <form onSubmit={handleCheckEmail} style={{marginTop:8}}>
                  <textarea value={emailInput} onChange={e=>setEmailInput(e.target.value)} placeholder="Paste full email body or raw source here" rows={6} style={{width:'100%',padding:8,borderRadius:6,border:'1px solid #e5e7eb'}} />
                  <div style={{display:'flex', justifyContent:'flex-end', marginTop:8}}>
                    <button style={styles.primary} disabled={loading}>Analyze</button>
                  </div>
                </form>
              </section>
            )}

            {(selected==='baiting' || selected==='quid-pro-quo') && (
              <section style={{marginBottom:16}}>
                <h3 style={{fontWeight:600}}>Upload and scan a file</h3>
                <div onDrop={onDrop} onDragOver={onDragOver} style={{marginTop:8,border:'2px dashed #e5e7eb',padding:16,borderRadius:8,textAlign:'center'}}>
                  <div style={{marginBottom:8}}>Drag & drop a file here, or</div>
                  <div style={{display:'flex',justifyContent:'center',alignItems:'center',gap:8}}>
                    <input ref={fileRef} type="file" style={{display:'none'}} onChange={e=>setFile(e.target.files?.[0]||null)} />
                    <button onClick={()=>fileRef.current?.click()} style={styles.button}>Choose file</button>
                    <div style={{fontSize:13,color:'#6b7280'}}>{file ? file.name : 'No file chosen'}</div>
                  </div>
                  <div style={{marginTop:12, display:'flex', justifyContent:'flex-end'}}>
                    <button onClick={handleUploadFile} style={styles.primary} disabled={loading || !file}>Upload & Scan</button>
                  </div>
                </div>
              </section>
            )}

            {(selected==='pretexting' || selected==='tailgating') && (
              <section>
                <h3 style={{fontWeight:600}}>Guidance & Indicators</h3>
                <div style={{marginTop:8, fontSize:14, color:'#374151'}}>
                  <p><strong>Pretexting:</strong> Look for urgent requests for credentials, odd sender addresses, or pressure to act quickly.</p>
                  <p><strong>Tailgating:</strong> Verify badges, check logs, and never prop open secure doors.</p>
                  <p style={{color:'#6b7280'}}>Use the Scanner above to analyze technical artifacts (links, files, headers).</p>
                </div>
              </section>
            )}

            <section style={{marginTop:16}}>
              <h3 style={{fontWeight:600}}>Result</h3>
              <div style={{marginTop:8, padding:12, background:'#f8fafc', borderRadius:6, minHeight:120}}>
                {loading ? <div style={{color:'#6b7280'}}>Scanning…</div> : result ? <pre style={{whiteSpace:'pre-wrap',fontSize:13}}>{prettyJSON(result)}</pre> : <div style={{color:'#9ca3af'}}>No results yet. Run a scan above.</div>}
              </div>
            </section>

            <section style={{marginTop:16}}>
              <h3 style={{fontWeight:600}}>Scan history</h3>
              <div style={{marginTop:8, display:'grid', gap:8}}>
                {history.length===0 && <div style={{color:'#9ca3af'}}>No history yet.</div>}
                {history.map((h,i)=> (
                  <div key={i} style={{border:'1px solid #e5e7eb',borderRadius:6,padding:8,background:'white'}}>
                    <div style={{fontSize:12,color:'#6b7280'}}>{new Date(h.when).toLocaleString()}</div>
                    <div style={{fontWeight:600}}>{h.type}</div>
                    <div style={{fontSize:13, overflow:'hidden', textOverflow:'ellipsis'}}>{JSON.stringify(h.data).slice(0,300)}</div>
                  </div>
                ))}
              </div>
            </section>

          </div>
        </div>
      </main>
    </div>
  );
}
