from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from phishing_detector import check_url, check_email
from malware_scanner import scan_file
import os
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
CORS(app)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 200 * 1024 * 1024  # 200 MB max uploads

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok'})

@app.route('/check-url', methods=['POST'])
def check_url_route():
    data = request.get_json() or {}
    url = data.get('url', '')
    result = check_url(url)
    return jsonify(result)

@app.route('/check-email', methods=['POST'])
def check_email_route():
    data = request.get_json() or {}
    email = data.get('email', '')
    result = check_email(email)
    return jsonify(result)

@app.route('/upload-file', methods=['POST'])
def upload_file_route():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    f = request.files['file']
    if f.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    filename = secure_filename(f.filename)
    path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    f.save(path)
    result = scan_file(path)
    return jsonify(result)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
