import re
from urllib.parse import urlparse
import html

# Basic blacklist and heuristics. Extend or replace with real feeds.
BLACKLIST = {
    'phishingsite.com',
    'scammer.net',
    'malicious.example'
}

SUSPICIOUS_PHRASES = [
    'verify your account',
    'update your payment',
    'click here to',
    'your account has been suspended',
    'confirm your identity',
    'urgent action required'
]

URL_REGEX = re.compile(r'http[s]?://[^\s\)\>\"]+')

def _extract_domain(url):
    try:
        p = urlparse(url)
        host = p.netloc.lower()
        if host.startswith('www.'):
            host = host[4:]
        return host
    except Exception:
        return ''

def _has_ip(url):
    # crude check for IPv4 in host
    m = re.search(r'\b\d{1,3}(?:\.\d{1,3}){3}\b', url)
    return bool(m)

def check_url(url: str):
    url = (url or '').strip()
    suspicious = False
    reasons = []
    domain = _extract_domain(url)
    if not url:
        return {'url': url, 'suspicious': False, 'reasons': ['Empty URL']}

    # blacklist
    for bad in BLACKLIST:
        if bad in domain:
            suspicious = True
            reasons.append(f'Blacklisted domain: {bad}')

    # IP in URL
    if _has_ip(url):
        suspicious = True
        reasons.append('IP address used in URL')

    # length heuristic
    if len(url) > 120:
        suspicious = True
        reasons.append('Very long URL')

    # many subdomains (possible homograph/typo-squatting)
    if domain.count('.') >= 4:
        suspicious = True
        reasons.append('Many subdomains in domain')

    # suspicious characters
    if '@' in url or '%40' in url:
        suspicious = True
        reasons.append('Encoded or plain "@" in URL (possible credential leak)')

    # return summary score (simple)
    score = 1 if suspicious else 0
    return {'url': url, 'domain': domain, 'suspicious': bool(suspicious), 'score': score, 'reasons': reasons}

def check_email(email_text: str):
    text = (email_text or '').strip()
    suspicious = False
    reasons = []
    if not text:
        return {'suspicious': False, 'reasons': ['Empty email content'], 'links': []}

    lower = text.lower()
    # trigger phrases
    for p in SUSPICIOUS_PHRASES:
        if p in lower:
            suspicious = True
            reasons.append(f'Trigger phrase: "{p}"')

    # extract links
    links = URL_REGEX.findall(text)
    cleaned_links = [html.unescape(l.strip(')')) for l in links]
    if cleaned_links:
        suspicious = True
        reasons.append(f'Found {len(cleaned_links)} link(s) in email')
    # analyze each link minimally
    link_results = [check_url(l) for l in cleaned_links]

    # suspicious sender impersonation heuristics (simple)
    if 'from:' in lower and ('noreply' in lower or 'support' in lower):
        reasons.append('Sender appears like automated/service account (noreply/support) — check headers')

    return {'suspicious': bool(suspicious), 'reasons': reasons, 'links': link_results, 'snippet': text[:800]}
