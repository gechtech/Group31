console.log("Blocked page script loaded");
